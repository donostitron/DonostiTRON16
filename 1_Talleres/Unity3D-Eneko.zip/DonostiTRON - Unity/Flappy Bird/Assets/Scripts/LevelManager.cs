﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

namespace Gameplay
{
    public class LevelManager : MonoBehaviour
    {

        public enum GameState { Start, Play, GameOver };

        public float distanceBtwColumns = 10.0f;
        public float levelSpeed = 0.1f;
        public float startingPos = 30.0f;
        public float minY = -1.5f;
        public float maxY = 2.8f;

        public int score = 0;

		public Text scoreText = null;

        public GameObject columnToInstantiate = null;

        private GameObject[] columnArray = new GameObject[5];

        public GameState GS = GameState.Start;

        // Use this for initialization
        void Start()
        {
            // Create column groups
            float currPos = startingPos;
            for (int i = 0; i < columnArray.Length; i++)
            {
                columnArray[i] = Instantiate(columnToInstantiate);
                Vector3 pos = columnArray[i].transform.position;
                pos.x = currPos;
                pos.y = UnityEngine.Random.Range(minY, maxY);
                currPos += distanceBtwColumns;
                columnArray[i].transform.position = pos;
            }
        }

        // Update is called once per frame
        void Update()
        {
            switch (GS)
            {
                case GameState.Start:
                        break;

                case GameState.Play:
                        MoveColumns();
                        break;

                case GameState.GameOver:
                        break;
            }

            if (Input.GetKeyDown(KeyCode.Escape))
            {
                Application.Quit();
            }
        }

        public void SetStart()
        {
            GS = GameState.Start;
        }

        public void SetPlay()
        {
            GS = GameState.Play;
        }

        public void SetGameOver()
        {
            GS = GameState.GameOver;
        }

        public void IncScore()
        {
            score++;
			scoreText.text = score.ToString();
        }

        void MoveColumns()
        {
            for (int i = 0; i < columnArray.Length; i++)
            {
                Vector3 pos = columnArray[i].transform.position;
                pos.x -= levelSpeed;
                if (pos.x < -11.0f)
                {
                    pos.x = columnArray[GetPrevColPosInArray(i)].transform.position.x + distanceBtwColumns;
                    pos.y = UnityEngine.Random.Range(minY, maxY);
                }

                columnArray[i].transform.position = pos;
            }
        }

        int GetPrevColPosInArray(int currPos)
        {
            int toReturn = currPos - 1;
            if (toReturn < 0)
                toReturn = columnArray.Length - 1;

            return toReturn;
        }
    }
}


