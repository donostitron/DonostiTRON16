﻿using UnityEngine;
using System.Collections;

namespace Gameplay
{
    public class BirdController : MonoBehaviour
    {

        public float Impulse = 10.0f;
        public float RotationFactor = 2.5f;
        public GameObject LevelManager = null;
        public GameObject StartText = null;
        public GameObject GameOverText = null;
        public GameObject TitleText = null;

        private LevelManager LM;

        // Use this for initialization
        void Start()
        {
            LM = LevelManager.GetComponent<LevelManager>();
        }

        // Update is called once per frame
        void Update()
        {
            switch (LM.GS)
            {
                case Gameplay.LevelManager.GameState.Start:

                    if (Input.GetKeyDown(KeyCode.Space))
                    {
                        LM.SetPlay();
                        GetComponent<Rigidbody2D>().isKinematic = false;
                        StartText.SetActive(false);
                        TitleText.SetActive(false);
                    }

                    break;

                case Gameplay.LevelManager.GameState.Play:
                    // Get Keyboard to impulse
                    if (Input.GetKeyDown(KeyCode.Space))
                    {
                        GetComponent<Rigidbody2D>().velocity = Vector2.zero;
                        GetComponent<Rigidbody2D>().AddForce(Vector2.up * Impulse, ForceMode2D.Impulse);
                    }

                    // Rotate bird according to Y velocity
                    // Get velocity and Eusler Angles
                    float yVel = GetComponent<Rigidbody2D>().velocity.y;
                    Vector3 eulerAngles = GetComponent<Transform>().eulerAngles;

                    //Compute Angle depending on Y Vel
                    if (yVel >= 0.0f)
                    {
                        eulerAngles.z = GetComponent<Rigidbody2D>().velocity.y;
                    }
                    else
                    {
                        eulerAngles.z = GetComponent<Rigidbody2D>().velocity.y * RotationFactor * 2;
                    }

                    // Set angle
                    GetComponent<Transform>().eulerAngles = eulerAngles;

                    break;

                case Gameplay.LevelManager.GameState.GameOver:

                    if (Input.GetKeyDown(KeyCode.Space))
                    {
                        string currentScene = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;
                        UnityEngine.SceneManagement.SceneManager.LoadScene(currentScene);
                    }

                    break;
            }
            
        }

        void OnTriggerEnter2D(Collider2D coll)
        {
            if (coll.gameObject.name == "ScoreCollision")
            {
                LM.IncScore();
            }
        }

        void OnCollisionEnter2D(Collision2D coll)
        {
            LM.SetGameOver();
            GameOverText.SetActive(true);
            StartText.SetActive(true);
        }
    }

}

