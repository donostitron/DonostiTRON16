﻿using UnityEngine;
using System.Collections;

namespace Gameplay
{
    public class MovimientoContinuo : MonoBehaviour {

        public LevelManager LM = null;
        public GameObject parteIzquierda = null;
        public GameObject parteDerecha = null;
        public float multiplicadorVelocidad = 1.0f;
        private float velocidad;
        private float distancia;

        // Use this for initialization
        void Start()
        {
            // Get ground distance
            distancia = parteDerecha.transform.position.x - parteIzquierda.transform.position.x;
            velocidad = LM.levelSpeed * multiplicadorVelocidad;
        }

        // Update is called once per frame
        void Update()
        {
            if (LM.GS == LevelManager.GameState.Play)
            {
                // Get current position
                Vector3 posicionIzq = parteIzquierda.transform.position;
                Vector3 posicionDer = parteDerecha.transform.position;
                // Apply speed
                posicionIzq.x -= velocidad;
                posicionDer.x -= velocidad;
                // Check out of screen
                if (posicionIzq.x < -20.0f)
                {
                    posicionIzq.x = posicionDer.x + distancia;
                }
                if (posicionDer.x < -20.0f)
                {
                    posicionDer.x = posicionIzq.x + distancia;
                }
                // Apply position
                parteIzquierda.transform.position = posicionIzq;
                parteDerecha.transform.position = posicionDer;
            }
        }
    }
}